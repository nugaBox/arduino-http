---
name: Bug report - no ESP chip involved
about: Report bugs or crashes which don't use any attached hardware
title: ''
labels: bug
assignees: ''

---

* Operating system:
* Python version: (`python -V` to check this)

# Full esptool.py command line as run:

Example: esptool.py version


# Full output from esptool.py

(please copy and paste all lines of output)


# What is the expected behaviour?

Example: Print the version number


# Do you have any other information from investigating this?

Example: I tried on my friend's Windows 10 PC and the command works there


# Is there any other information you can think of which will help us reproduce this problem?

Example: Only crashes on first day of the month
